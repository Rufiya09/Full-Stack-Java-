package com.odigos.bank.exceptions;

public class AccountNotFound {

}
