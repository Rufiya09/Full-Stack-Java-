package com.odigos.bank.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.odigos.bank.model.Account;
import com.odigos.bank.model.Transaction;

public class BankDAOImpl implements BankDAO {
	int transactionId = 9000;
	HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();// database
	HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();

	@Override
	public String createAccount(Account account) {
		accounts.put(account.getAccountNo(), account);
		return "Account Created Successfully";
	}

	@Override
	public Account viewAccountDetails(int accountNo) {

		return accounts.get(accountNo);
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) {
		Account account = viewAccountDetails(accountNo);
		float oldBalance = account.getBalance();
		float updatedBalance = oldBalance - amountToWithdraw;
		account.setBalance(updatedBalance);
		accounts.put(accountNo, account);

		Transaction withdrawTransaction = new Transaction(++transactionId, "withdraw", new Date(), updatedBalance,
				oldBalance, accountNo, 0);
		transactions.put(transactionId, withdrawTransaction);
		return updatedBalance;
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) {
		Account account = viewAccountDetails(accountNo);
		float oldBalance = account.getBalance();
		float updatedBalance = oldBalance + amountToDeposit;
		account.setBalance(updatedBalance);
		accounts.put(accountNo, account);
		Transaction withdrawTransaction = new Transaction(++transactionId, "deposit", new Date(), updatedBalance,
				oldBalance, accountNo, 0);
		transactions.put(transactionId, withdrawTransaction);
		return updatedBalance;
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer) {
		// debit
		Account fromAccount = viewAccountDetails(fromAccountNo);
		float fromOldBalance = fromAccount.getBalance();
		float fromUpdatedBalance = fromOldBalance - amountToTransfer;
		fromAccount.setBalance(fromUpdatedBalance);
		accounts.put(fromAccountNo, fromAccount);
		// credit
		Account toAccount = viewAccountDetails(toAccountNo);
		float toOldBalance = toAccount.getBalance();
		float toUpdatedBalance = toOldBalance + amountToTransfer;
		toAccount.setBalance(toUpdatedBalance);
		accounts.put(toAccountNo, toAccount);
		Transaction withdrawTransaction = new Transaction(++transactionId, "fundtransfer", new Date(),
				fromUpdatedBalance, fromOldBalance, fromAccountNo, toAccountNo);
		transactions.put(transactionId, withdrawTransaction);
		return fromUpdatedBalance;
	}

	@Override
	public Set<Transaction> printTransactions() {
		Set<Integer> keys = transactions.keySet();
		Set<Transaction> trans = new HashSet<Transaction>();
		Iterator<Integer> itr = keys.iterator();
			while(itr.hasNext())
			{
				int key=itr.next();
				trans.add(transactions.get(key));
			}
		return trans;
	}

}
