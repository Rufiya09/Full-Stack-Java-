package com.odigos.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.odigos.bank.exceptions.AccountNotFound;
import com.odigos.bank.model.Account;
import com.odigos.bank.model.Transaction;

public class BankDAOImpl implements BankDAO {
	int transactionId = 9000;
	Connection conn = null;

	public BankDAOImpl() {
		try {
			conn = JdbcUtil.getConnection();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public String createAccount(Account account) throws SQLException {
		PreparedStatement psmt = conn.prepareStatement("insert into accounts values(?,?,?,?,?)");
		psmt.setInt(1, account.getAccountNo());
		psmt.setString(2, account.getAccountHolderName());
		psmt.setFloat(3, account.getBalance());
		psmt.setString(4, account.getBranch());
		psmt.setLong(5, account.getContactNo());
		psmt.executeUpdate();
		return "Account Created Successfully";
	}

	@Override
	public Account viewAccountDetails(int accountNo) throws SQLException, AccountNotFound {
		PreparedStatement psmt = conn.prepareStatement("select * from accounts where accountno=?");
		psmt.setInt(1, accountNo);
		ResultSet rs = psmt.executeQuery();
		if (rs.next()) {
			Account account = new Account(rs.getInt(1), rs.getString(2), rs.getFloat(3), rs.getString(4),
					rs.getLong(5));
			return account;
		} else {
			throw new AccountNotFound("Invalid Account Number...");
		}

	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) throws SQLException, AccountNotFound {
		Account account = viewAccountDetails(accountNo);
		float oldBalance = account.getBalance();
		float updatedBalance = oldBalance - amountToWithdraw;
		account.setBalance(updatedBalance);
		PreparedStatement psmt = conn.prepareStatement("update accounts set balance=? where accountNo=?");
		psmt.setFloat(1, updatedBalance);
		psmt.setInt(2, accountNo);
		int result = psmt.executeUpdate();
		if (result > 0) {
			psmt = conn.prepareStatement("insert into transactions values(?,?,?,?,?,?,?)");
			psmt.setInt(1, accountNo - 200);
			psmt.setString(2, "withdraw");
			psmt.setDate(3, new Date(04, 03, 2024));
			psmt.setFloat(4, updatedBalance);
			psmt.setFloat(5, oldBalance);
			psmt.setInt(6, accountNo);
			psmt.setInt(7, 0);
			result = psmt.executeUpdate();
			return updatedBalance;
		} else {
			throw new AccountNotFound("Somthing went wrong");
		}
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) throws SQLException, AccountNotFound {
		Account account = viewAccountDetails(accountNo);
		float oldBalance = account.getBalance();
		float updatedBalance = oldBalance + amountToDeposit;
		account.setBalance(updatedBalance);
		PreparedStatement psmt = conn.prepareStatement("update accounts set balance=? where accountNo=?");
		psmt.setFloat(1, updatedBalance);
		psmt.setInt(2, accountNo);
		int result = psmt.executeUpdate();
		if (result > 0) {
			psmt = conn.prepareStatement("insert into transactions values(?,?,?,?,?,?,?)");
			psmt.setInt(1, accountNo - 200);
			psmt.setString(2, "deposit");
			psmt.setDate(3, new Date(04, 03, 2024));
			psmt.setFloat(4, updatedBalance);
			psmt.setFloat(5, oldBalance);
			psmt.setInt(6, accountNo);
			psmt.setInt(7, 0);
			result = psmt.executeUpdate();
			return updatedBalance;
		} else {
			throw new AccountNotFound("Somthing went wrong");
		}
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer)
			throws SQLException, AccountNotFound {
		// debit
		Account fromAccount = viewAccountDetails(fromAccountNo);
		float fromOldBalance = fromAccount.getBalance();
		float fromUpdatedBalance = fromOldBalance - amountToTransfer;
		fromAccount.setBalance(fromUpdatedBalance);
		PreparedStatement psmt = conn.prepareStatement("update accounts set balance=? where accountNo=?");
		psmt.setFloat(1, fromUpdatedBalance);
		psmt.setInt(2, fromAccountNo);
		psmt.executeUpdate();
		// credit
		Account toAccount = viewAccountDetails(toAccountNo);
		float toOldBalance = toAccount.getBalance();
		float toUpdatedBalance = toOldBalance + amountToTransfer;
		toAccount.setBalance(toUpdatedBalance);
		psmt = conn.prepareStatement("update accounts set balance=? where accountNo=?");
		psmt.setFloat(1, toUpdatedBalance);
		psmt.setInt(2, toAccountNo);
		int result = psmt.executeUpdate();
		if (result > 0) {
			psmt = conn.prepareStatement("insert into transactions values(?,?,?,?,?,?,?)");
			psmt.setInt(1, fromAccountNo - 200);
			psmt.setString(2, "fundtransfer");
			psmt.setDate(3, new Date(04, 03, 2024));
			psmt.setFloat(4, fromUpdatedBalance);
			psmt.setFloat(5, fromOldBalance);
			psmt.setInt(6, fromAccountNo);
			psmt.setInt(7, toAccountNo);
			result = psmt.executeUpdate();
			return fromUpdatedBalance;
		} else {
			throw new AccountNotFound("Somthing went wrong");
		}

	}

	@Override
	public Set<Transaction> printTransactions() throws SQLException, AccountNotFound {
		HashSet<Transaction> trans = new HashSet<Transaction>();
		PreparedStatement psmt = conn.prepareStatement("select * from transactions");
		ResultSet rs = psmt.executeQuery();
		while (rs.next()) {
			Transaction transaction = new Transaction(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getFloat(4),
					rs.getFloat(5), rs.getInt(6), rs.getInt(7));
			trans.add(transaction);
		}
		return trans; 
	}

}
